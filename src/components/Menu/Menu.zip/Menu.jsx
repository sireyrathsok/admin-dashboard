import React, { useState } from "react";
import { motion } from "framer-motion";
import img1 from "../../assets/icecream.jpg";
import spa from "../../assets/spa.jpg";
import ice from "../../assets/ice.jpg";
import choIce from "../../assets/choIce.jpg";
import tacco1 from "../../assets/tacco1.jpg";
import tacco2 from "../../assets/tacco2.jpg";
import bowIce from "../../assets/bowls-with-ice-cream.jpg";
import dietTacco from "../../assets/dietTacco.jpg";
import Sbread from "../../assets/bread-wooden-tray-red-white-cloth.jpg";
import sandwich1 from "../../assets/sandwich1.jpg";
import burger from "../../assets/burger.jpg";
import chwing from "../../assets/chwing.jpg";
import milktea from "../../assets/milktea.jpg";
import settacco from "../../assets/settacco.jpg";
import chFried from "../../assets/chFried.jpg";
import riceOmo from "../../assets/riceOmo.jpg";
import doubleBurger from "../../assets/doubleBurger.jpg";
import chSet from "../../assets/chSet.jpg";
import dumpling from "../../assets/dumpling.jpg";
import macaroni from "../../assets/french-colorful-macaroons.jpg";
import sushiCol from "../../assets/sushiCol.jpg";
import donut from "../../assets/donut.jpg";
import breadSet from "../../assets/breadSet.jpg";
import sushiMini from "../../assets/sushiMini.jpg";
import lateCof from "../../assets/iced-latte-coffee.jpg";
import lemondrink from "../../assets/chFried.jpg";
import meatball from "../../assets/meatball.jpg";
import porkNoo from "../../assets/porkNoo.jpg";
import SpiNoo from "../../assets/SpiNoo.jpg";
import TomYum from "../../assets/TomYum.jpg";
import americano from "../../assets/americano.jpg";
import espresso from "../../assets/espresso.jpg";

const menuList = [
  {
    imgUrl: spa,
    name: "Spagetti with Shrimp",
    price: "4.5",
    rating: 4,
    popular: true,
  },
  {
    imgUrl: ice,
    name: "Causaul Icecream",
    price: "2.5",
    rating: 3,
    popular: true,
  },
  {
    imgUrl: choIce,
    name: "Chocolate Icecream",
    price: "3.5",
    rating: "4",
    popular: true,
  },
  {
    imgUrl: tacco1,
    name: "Original tacco",
    price: "2.5",
    rating: 3,
    popular: true,
  },
  {
    imgUrl: tacco2,
    name: "Special Tacco",
    price: "4.7",
    rating: "",
    popular: false,
  },
  {
    imgUrl: bowIce,
    name: "Bowl Icecream",
    price: "4.5",
    rating: 4,
    popular: false,
  },
  {
    imgUrl: dietTacco,
    name: "Tacco For Diet",
    price: "4.7",
    rating: 4,
    popular: false,
  },
  {
    imgUrl: Sbread,
    name: "Bread",
    price: "2.2",
    rating: 3,
    popular: false,
  },
  {
    imgUrl: sandwich1,
    name: "Causual Sandwich",
    price: "2",
    rating: "4",
    popular: true,
  },
  {
    imgUrl: burger,
    name: "Spacial Burger",
    price: "5",
    rating: "5",
    popular: true,
  },
  {
    imgUrl: chwing,
    name: "Chicken Wings ",
    price: "3.5",
    rating: "4",
    popular: true,
  },
  {
    imgUrl: milktea,
    name: "Milk Tea with Pearl",
    price: "2.5",
    rating: "3",
    popular: false,
  },
  {
    imgUrl: settacco,
    name: "Tacco Friend Set",
    price: "6.5",
    rating: "5",
    popular: true,
  },
  {
    imgUrl: chFried,
    name: "Chicken Fried",
    price: "3.5",
    rating: 4,
    popular: false,
  },
  {
    imgUrl: riceOmo,
    name: "Rice with Omolet",
    price: "4.5",
    rating: "5",
    popular: true,
  },
  {
    imgUrl: doubleBurger,
    name: "Double Burger",
    price: "5.5",
    rating: "",
    popular: true,
  },
  {
    imgUrl: chSet,
    name: "Chicken + French Fried Set",
    price: "5.5",
    rating: "",
    popular: true,
  },
  {
    imgUrl: dumpling,
    name: "Japaness Dumpling",
    price: "7",
    rating: "5",
    popular: true,
  },
  {
    imgUrl: macaroni,
    name: "French Macarrom",
    price: "4",
    rating: "",
    popular: false,
  },
  {
    imgUrl: sushiCol,
    name: "Sushi Collection",
    price: "20",
    rating: "",
    popular: false,
  },
  {
    imgUrl: donut,
    name: "Sweet Donut",
    price: "3.5",
    rating: "",
    popular: false,
  },
  {
    imgUrl: breadSet,
    name: "Bread Mini Set",
    price: "4.5",
    rating: "",
    popular: false,
  },
  {
    imgUrl: sushiMini,
    name: "Sushi Mini set",
    price: "2.5",
    rating: "",
    popular: false,
  },
  {
    imgUrl: lateCof,
    name: "Iced Latte Coffee",
    price: "2.5",
    rating: "",
    popular: true,
  },
  {
    imgUrl: lemondrink,
    name: "Fresh Lemonade",
    price: "1.5",
    rating: "",
    popular: false,
  },
  {
    imgUrl: meatball,
    name: "Spicy Meatball",
    price: "2.5",
    rating: "",
    popular: true,
  },
  {
    imgUrl: porkNoo,
    name: "Pork Noodle",
    price: "3.5",
    rating: "",
    popular: false,
  },
  {
    imgUrl: SpiNoo,
    name: "Spicy Noodle + Pork",
    price: "3.5",
    rating: "",
    popular: true,
  },
  {
    imgUrl: TomYum,
    name: "Tom Yum Noodle ",
    price: "3.5",
    rating: "",
    popular: false,
  },
  {
    imgUrl: americano,
    name: "Hot Americano",
    price: "2.5",
    rating: "",
    popular: false,
  },
  {
    imgUrl: espresso,
    name: "Hot Espresso ",
    price: "2.5",
    rating: "",
    popular: true,
  },
];

const Menu = () => {
  const [AllisClicked, setAllisClicked] = useState(true);
  const [PopularisClicked, setPopularisClicked] = useState(false);
  return (
    <div className=" text-white ">
      <div className=" flex justify-start  sm:justify-end gap-5  text-white  mb-5  ">
        <button className=" bg-orange-400 hover:bg-orange-500 px-6 py-1 rounded-lg ">
          All
        </button>
        <button className=" bg-orange-400  hover:bg-orange-500 px-6 py-1 rounded-lg ">
          Popular
        </button>
      </div>
      <section className=" sm:grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols- gap-8 sm:gap-10 xl:gap-12 overflow-x-hidden">
        {menuList.map((item, index) => {
          const allMenu = [{}];
          {
            /* return (
            <div>
              <p>Testing</p>
            </div>
          ); */
          }
          {
            return (
              <motion.div
                whileHover={{ scale: 1.07 }}
                key={index}
                className=" mb-16 sm:mb-0"
              >
                <img
                  className=" xxs:h-[320px] xs:h-[350px] sm:h-[220px] md:h-56 lg:h-52 xl:h-60 w-full rounded-t-xl"
                  src={item.imgUrl}
                  alt="product"
                />
                <div className="  bg-gray-600 px-3 py-3 rounded-b-xl ">
                  <div>
                    <p className=" text-md text-gray-400">{item.name}</p>
                  </div>

                  <div className=" flex justify-between items-center">
                    <p className=" my-4 text-lg text-gray-300">${item.price}</p>
                    <p className=" bg-gray-500 hover:bg-gray-400 px-3 py-1  rounded-lg">
                      Details
                    </p>
                  </div>
                </div>
              </motion.div>
            );
          }
        })}
      </section>
    </div>
  );
};

export default Menu;
